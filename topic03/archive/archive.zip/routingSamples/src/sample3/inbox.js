import React from "react";
import { withRouter } from "react-router-dom";

const BaseInbox = props => {
  return (
    <>
      <h2>Inbox page</h2>
      <h3>Messages for user: {props.match.params.userId} </h3>
    </>
  );
};

export default withRouter(BaseInbox);
