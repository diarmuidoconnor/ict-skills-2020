import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import { About } from "../sample1";
import Inbox from "./inbox";

const Home = () => {
    return (
      <>
        <h1>Home page</h1>
        <h3>Nested route demo</h3>
        <p>
          Try <Link to='/inbox/1234'> this link</Link>
          <span> for basic inbox page.</span>
        </p>
        <p>
          Try{" "}
          <Link to='/inbox/1234/statistics'> this link</Link>
          <span> for page with inbox and email statistics.</span>
        </p>
        <p>
          Try <a href="http://localhost:3000/inbox/1234/drafts"> this link</a>
          <span> for page with inbox and draft emails.</span>
        </p>
      </>
    );
  }

const App = () => {
    return (
      <BrowserRouter>
        <Switch>
          <Route path="/about" component={About} />
          <Route path="/inbox/:userId" component={Inbox} />
          <Route exact path="/" component={Home} />
          <Redirect from="*" to="/" />
        </Switch>
      </BrowserRouter>
    );
  }

ReactDOM.render(<App />, document.getElementById("root"));
