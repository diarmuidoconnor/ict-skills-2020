import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch } from "react-router-dom";

export const About = () => {
  return <h2>About page</h2>;
};

export const Inbox = () => {
  return <h2>Inbox page</h2>;
};

const Home = () => {
  return <h1>Home page</h1>;
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/about" component={About} />
        <Route path="/inbox" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
